/*****************************************************************************************************
   Copyright (C) 2012, Oplink Communications Inc.
   FileName:      DevCVData.h
   Author:        Zhu WeiAn
   Date:          2022-10-10
   Version:       1.0
   Description:
   Function List:

   History:
   [Zhu WeiAn] [2022-10-10] [1.0] [Creator]


*****************************************************************************************************/

typedef enum enCvLine {

    CV_LINE_W = 0,
    CV_LINE_P,

    CV_LINE_CNT

} EnCvLine;


typedef struct {
    bool bOnline;
    double dOutputPowerR;  /* R represent Mux-R on panel*/
    double dInputPowerR;
    double dOutputPowerT;  /* T represent Mux-T on panel */
    double dInputPowerT;

} CCvMuxStatusData;

typedef struct {
    bool bOnline;
    double dDfbOutputPower;
    double dOutputPowerR; /* Client-R on AMP */
    double dInputPowerR;
    double dOutputPowerT; /* Client-T on AMP */
    double dInputPowerT;

} CCvClientStatusData;

typedef struct {
    double dOutputPower;
    double dRefPower;
} CCvRef;